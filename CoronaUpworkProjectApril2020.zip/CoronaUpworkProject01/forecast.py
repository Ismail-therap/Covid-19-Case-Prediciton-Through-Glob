import pandas as pd
from datetime import datetime
import numpy as np
from data import geo_json_creator
from new import scrape
import warnings
import os

warnings.filterwarnings("ignore")

def exists(name):
    if os.path.isfile('geojson/historical/{}'.format(name)):
        return True
    else:
        return False

def predictor(verbose=True):
    if(verbose):
        print("\n\n-----Running The Forecst Script-----\n")

    if(verbose):
        print("Reading data from CSV Files")
    cur = pd.read_csv("data.csv")
    timeline = pd.read_csv("timeseries-jhu.csv")
    if(verbose):
        print("COMPLETED\n")

    if(verbose):
        print("Pre-processing Data")


    cur["id"] = cur["country"]
    timeline["id"] = timeline["country"]


    for index, row in cur.iterrows():
        string = ""
        if(type(row["city"]) is str):
            string = string + row["city"]
        if(type(row["county"]) is str):
            string = string + row["county"]
        if(type(row["state"]) is str):
            string = string + row["state"]   
        if(type(row["country"]) is str):
            string = string + row["country"]
        cur.at[index,"id"]=string


    for index, row in timeline.iterrows():
        string = ""
        if(type(row["city"]) is str):
            string = string + row["city"]
        if(type(row["county"]) is str):
            string = string + row["county"]
        if(type(row["state"]) is str):
            string = string + row["state"]   
        if(type(row["country"]) is str):
            string = string + row["country"]
        timeline.at[index,"id"]=string


    cols = timeline.columns.tolist()
    cols = cols[-1:] + cols[:-1]
    timeline = timeline[cols]

    x = datetime.today().strftime('%Y-%m-%d')


    x = list(timeline.columns)
    unwanted =['id', 'city', 'county', 'state', 'country', 'lat', 'long', 'population','url']
    for i in unwanted:
        x.remove(i)

    today=x[-1]
    with open("today.txt","w") as fp:
        fp.writelines(today)

    x.remove(today)
    yday = x[-1]
    print(yday)
    x.reverse()
    unwanted.append('cases')

    if(verbose):
        print("COMPLETED\n")

    if(verbose):
        print("Combining Timeline-JHU and Data CSVs")
    df = cur[unwanted]
    df["today"]= df["cases"]
    df["t-1"]= df["cases"]
    df["t-2"]= df["cases"]
    df["t-3"]= df["cases"]

    skipped = 0
    skiplist = []
    misslist = []
    print(df)
    for index, row in df.iterrows():
    #     print(index,row["id"])

        a = timeline[(timeline.iloc[:,0])==row["id"].strip()]
        # print(a)
        try:
            last_3 =[int(row["cases"])]
        except:
            index2 = a[yday].index[0]
            if(verbose):
                print("Error with {}. Cases reported for today is EMPTY".format(a["id"]))
                print("Skipping ... ")
                skiplist.append(index)
            continue
        
        try:
            index2 = a["id"].index[0]
        except:
            print("Error")
            print(row["id"])
            misslist.append(index)
            continue
    #     print(a["id"])
    #     print(index2)
        num=0
        while(num<3):
            i = x[num]
        #   print(a[i][index] )
    #         if(num==0):
    #             print(a[i][index2])
            if(a[i][index2]==0):
                last_3.append(int(a[i][index2]))
            elif(pd.notnull((a[i][index2]))):
                last_3.append(int(a[i][index2]))
            else:
                last_3.append(last_3[num])
            num+=1
        
    #     print(last_3)
        df.at[index,"today"]=last_3[0]
        df.at[index,"t-1"]=last_3[1]
        df.at[index,"t-2"]=last_3[2]
        df.at[index,"t-3"]=last_3[3]

    print(skiplist)
    print(misslist)
    for i in skiplist:
        df = df.drop(axis=0, index=i)

    df["percent1"] = 0.0
    df["percent2"] = 0.0
    df["percent3"] = 0.0
    df["percent"] = 0.0
    df["tdp1"]= df["cases"]
    df["tdp2"]= df["cases"]
    df["tdp3"]= df["cases"]
    df["tdp4"]= df["cases"]
    df["tdp5"]= df["cases"]
    df["tdp6"]= df["cases"]
    df["tdp7"]= df["cases"]
    df["tdp8"]= df["cases"]
    df["tdp9"]= df["cases"]
    df["tdp10"] = df["cases"]

    if(verbose):
        print("COMPLETED\n")

    if(verbose):
        print("Calculating Percentage Increases")
    df['percent1'] = ((abs(df['today']-df['t-1']))/df['t-1'])*100
    for i,v in df["percent1"].iteritems():
        if(v ==np.inf):
            df["percent1"][i] = (abs(df['today'][i]-1)/1)*100
        elif(np.isnan(v)):
            df["percent1"].at[i] = 0

            
    df['percent2'] = (abs(df['t-1']-df['t-2'])/df['t-2'])*100
    for i,v in df["percent2"].iteritems():
        if(v ==np.inf):
            df["percent2"][i] = (abs(df['t-1'][i]-1)/1)*100
        elif(np.isnan(v)):
            df["percent2"][i] = 0
            

    df['percent3'] = (abs(df['t-2']-df['t-3'])/df['t-3'])*100
    for i,v in df["percent3"].iteritems():
        if(v ==np.inf):
            df["percent3"][i] = (abs(df['t-2'][i]-1)/1)*100
        elif(np.isnan(v)):
            df["percent3"][i] = 0

    for index,row in df.iterrows():
        prev = [row["t-1"],row["t-2"],row["t-3"]]
        if(all(prev)):
            df.at[index,"percent"]= (df.at[index,"percent1"]+df.at[index,"percent2"]+df.at[index,"percent3"])/3
            if(df.at[index,"percent"]>100 and df.at[index,"today"]<100):
                df.at[index,"percent"]=100
            if(df.at[index,"percent"]>55 and df.at[index,"today"]>=100):
                df.at[index,"percent"]=55
        else:
            df.at[index,"percent"]=0

    df["tdp1"] = (df["today"]*df["percent"])/100 + df["today"]
    df["tdp2"] = (df["tdp1"]*df["percent"])/100 + df["tdp1"]
    df["tdp3"] = (df["tdp2"]*df["percent"])/100 + df["tdp2"]
    df["tdp4"] = (df["tdp3"]*df["percent"])/100 + df["tdp3"]
    df["tdp5"] = (df["tdp4"]*df["percent"])/100 + df["tdp4"]
    df["tdp6"] = (df["tdp5"]*df["percent"])/100 + df["tdp5"]
    df["tdp7"] = (df["tdp6"]*df["percent"])/100 + df["tdp6"]
    df["tdp8"] = (df["tdp7"]*df["percent"])/100 + df["tdp7"]
    df["tdp9"] = (df["tdp8"]*df["percent"])/100 + df["tdp8"]
    df["tdp10"] = (df["tdp9"]*df["percent"])/100 + df["tdp9"]

    for i,v in df['tdp1'].iteritems():
        df["tdp1"][i] = int(round(v))
        
    for i,v in df['tdp2'].iteritems():
        df["tdp2"][i] = int(round(v))
        
    for i,v in df['tdp3'].iteritems():
        df["tdp3"][i] = int(round(v))

    for i,v in df['tdp4'].iteritems():
        df["tdp4"][i] = int(round(v))
        
    for i,v in df['tdp5'].iteritems():
        df["tdp5"][i] = int(round(v))
        
    for i,v in df['tdp6'].iteritems():
        df["tdp6"][i] = int(round(v))
        
    for i,v in df['tdp7'].iteritems():
        df["tdp7"][i] = int(round(v))
        
    for i,v in df['tdp8'].iteritems():
        df["tdp8"][i] = int(round(v))
        
    for i,v in df['tdp9'].iteritems():
        df["tdp9"][i] = int(round(v))

    for i,v in df['tdp10'].iteritems():
        df["tdp10"][i] = int(round(v))

    if(verbose):
        print("COMPLETED\n")

    if(verbose):
        print("Saving Data into CSVs")
    df.to_csv("datasheet.csv")
    df_tdp1 = df[['city', 'county', 'state', 'country','tdp1','lat', 'long', 'population','url']]
    df_tdp2 = df[['city', 'county', 'state', 'country','tdp2','lat', 'long', 'population','url']]
    df_tdp3 = df[['city', 'county', 'state', 'country','tdp3','lat', 'long', 'population','url']]
    df_tdp4 = df[['city', 'county', 'state', 'country','tdp4','lat', 'long', 'population','url']]
    df_tdp5 = df[['city', 'county', 'state', 'country','tdp5','lat', 'long', 'population','url']]
    df_tdp6 = df[['city', 'county', 'state', 'country','tdp6','lat', 'long', 'population','url']]
    df_tdp7 = df[['city', 'county', 'state', 'country','tdp7','lat', 'long', 'population','url']]
    df_tdp8 = df[['city', 'county', 'state', 'country','tdp8','lat', 'long', 'population','url']]
    df_tdp9 = df[['city', 'county', 'state', 'country','tdp9','lat', 'long', 'population','url']]
    df_tdp10 = df[['city', 'county', 'state', 'country','tdp10','lat', 'long', 'population','url']]

    df_tdp1 = df_tdp1.rename(columns={'tdp1': 'cases'})
    df_tdp2 = df_tdp2.rename(columns={'tdp2': 'cases'})
    df_tdp3 = df_tdp3.rename(columns={'tdp3': 'cases'})
    df_tdp4 = df_tdp4.rename(columns={'tdp4': 'cases'})
    df_tdp5 = df_tdp5.rename(columns={'tdp5': 'cases'})
    df_tdp6 = df_tdp6.rename(columns={'tdp6': 'cases'})
    df_tdp7 = df_tdp7.rename(columns={'tdp7': 'cases'})
    df_tdp8 = df_tdp8.rename(columns={'tdp8': 'cases'})
    df_tdp9 = df_tdp9.rename(columns={'tdp9': 'cases'})
    df_tdp10 = df_tdp10.rename(columns={'tdp10': 'cases'})

    df_tdp1.to_csv("geojson/tdp1.csv")
    df_tdp2.to_csv("geojson/tdp2.csv")
    df_tdp3.to_csv("geojson/tdp3.csv")
    df_tdp4.to_csv("geojson/tdp4.csv")
    df_tdp5.to_csv("geojson/tdp5.csv")
    df_tdp6.to_csv("geojson/tdp6.csv")
    df_tdp7.to_csv("geojson/tdp7.csv")
    df_tdp8.to_csv("geojson/tdp8.csv")
    df_tdp9.to_csv("geojson/tdp9.csv")
    df_tdp10.to_csv("geojson/tdp10.csv")

    if(verbose):
        print("COMPLETED\n")
    
    if(verbose):
        print("Creating JSONs for Next 10 Days")
    geo_json_creator("geojson/tdp1.csv","tdp1.geo.json",verbose=False,extras=False)
    geo_json_creator("geojson/tdp2.csv","tdp2.geo.json",False,False)
    geo_json_creator("geojson/tdp3.csv","tdp3.geo.json",False,False)
    geo_json_creator("geojson/tdp4.csv","tdp4.geo.json",False,False)
    geo_json_creator("geojson/tdp5.csv","tdp5.geo.json",False,False)
    geo_json_creator("geojson/tdp6.csv","tdp6.geo.json",False,False)
    geo_json_creator("geojson/tdp7.csv","tdp7.geo.json",False,False)
    geo_json_creator("geojson/tdp8.csv","tdp8.geo.json",False,False)
    geo_json_creator("geojson/tdp9.csv","tdp9.geo.json",False,False)
    geo_json_creator("geojson/tdp10.csv","tdp10.geo.json",False,False)

    if(verbose):
        print("Successfully Created JSONs For the Next 10 Days!\n\n")

        print("To Visualize the Data Visit: http://www.coviddatascience.com/map.html")
        print("To Download the Data File Created Visit: http://www.coviddatascience.com/datasheet.csv")
        print("To Download the Johns Hopkins Timeline Data Visit: http://www.coviddatascience.com/timeline-jhu.csv")


def history(verbose=True):
    if(verbose):
        print("\n-----Running Historical Data Script-----\n\n")

    if(verbose):
        print("Checking CSV Files for past data ...\n")

    timeline = pd.read_csv("timeseries-jhu.csv")
    timedata = pd.read_csv("timeseries.csv")
        

    x = list(timeline.columns)
    unwanted =['city', 'county', 'state', 'country', 'lat', 'long', 'population','url']
    for i in unwanted:
        x.remove(i)

    for i in ['aggregate','tz']:
        if i in x:
            x.remove(i)
    
    x.remove(x[-1])
    gb = timedata.groupby('date')    
    ls = [gb.get_group(x) for x in gb.groups]

    if(verbose):
        print("Checking directory to see if past files exist ... \n")

    for num in range(0,len(x)):
        try:
            name = x[num]+".csv"
            ls[num] = ls[num].drop(['date'],axis=1)
            if exists(name):
                continue
            ls[num].to_csv("geojson/historical/"+name)
            print("Created new file: {}".format(name))
        except:
            print(x[num])

    if(verbose):
        print("Updating GeoJSONs for past dates\n")
    for num in range(0,len(x)):
        namecsv = x[num]+".csv"
        namejson = x[num]+".geo.json"
        path = "geojson/historical/"
        if exists(namejson):
            continue
        geo_json_creator(path+namecsv,namejson,verbose=False,extras=False,historical=True)
        print("Created GeoJson {}".format(namejson))

    if(verbose):
        print("\nDone.")


if __name__ =="__main__":
    scrape()
    geo_json_creator("data.csv")
    history()
    predictor()
    
